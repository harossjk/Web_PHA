1. 프로젝트 개요

   - 고객사 : 평화정공 현풍 공장
   - 개발 시스템 명 : 금형 관리 시스템


2. 개발 환경

   - 주요 개발 라이브러리 : React
   - 언어 : Typescript
   - 상태관리 : MobX
   - CSS style : SCSS
   - 디자인패턴 : presentational and container design pattern

3. 프로젝트 디렉터리 구성

   - asset : 프로젝트의 기준 데이터와 img 등의 source를 가진 디렉터리.
   - components : props만 가진 pure component로 구성된 react comp를 가진 디렉터리.
   - pages : components 디렉터리 내의 react comp를 조합한 presentational component인 pages를 가진 디렉터리.
   - containers : pages의 데이터 조작과 이벤트 처리를 담당하는 containers를 가진 디렉터리.
   - stores : MobX Data Store를 가진 디렉터리.

4. 페이지 구성

   - Layout : Container 를 스위칭하는 Home page.


5. 컨테이너 구성

   - XXXCanvasContainer : comment.