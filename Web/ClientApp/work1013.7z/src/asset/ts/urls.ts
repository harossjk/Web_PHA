import { concat } from "lodash";
import { ILinkInfo } from "../../stores/appManager";

export const baseInfoList: ILinkInfo[] = [
    {category: '기준 정보', label:'사용자 관리', url: '/baseinfo/user'},
    {category: '기준 정보', label:'기초 코드 설정', url: '/baseinfo/basecode'}, 
    {category: '기준 정보', label:'차종 관리', url: '/baseinfo/cartype'}, 
    {category: '기준 정보', label:'품목 관리', url: '/baseinfo/recipe'}, 
    {category: '기준 정보', label:'금형 마스터 관리', url: '/baseinfo/moldmaster'}, 
    {category: '기준 정보', label:'예방점검 시트 관리', url: '/baseinfo/checksheet'}, 
    {category: '기준 정보', label:'RFID Code 관리', url: '/baseinfo/rfidcode'}, 
    {category: '기준 정보', label:'협력사 관리', url: '/baseinfo/partners'}
];
export const moldCntList: ILinkInfo[] = [
    {category: '금형 타수/세척', label:'금형 타수', url: '/moldcnt/cnt'},
    {category: '금형 타수/세척', label:'금형 세척', url: '/moldcnt/clean'},
    {category: '금형 타수/세척', label:'금형 수정', url: '/moldcnt/modify'}
];
export const moldRepairList: ILinkInfo[] = [
    {category: '금형 수리', label:'금형 수리 의뢰', url: '/moldrepair/request'},
    {category: '금형 수리', label:'금형 수리 완료 등록', url: '/moldrepair/registration'},
    {category: '금형 수리', label:'금형 수리 현황 조회', url: '/moldrepair/report'}
];
export const moldCheckList: ILinkInfo[] = [
    {category: '금형 예방 점검', label:'정기 점검', url: '/moldcheck/routine'},
    {category: '금형 예방 점검', label:'정기 점검 현황', url: '/moldcheck/routinereport'},
    {category: '금형 예방 점검', label:'일상 점검', url: '/moldcheck/daily'},
    {category: '금형 예방 점검', label:'예방 점검 NG 조치 등록', url: '/moldcheck/ngregistration'}
];
export const moldInOutList: ILinkInfo[] = [
    {category: '금형 입/출고', label:'금형 입고', url: '/moldinout/in'},
    {category: '금형 입/출고', label:'금형 출고', url: '/moldinout/out'},
    {category: '금형 입/출고', label:'금형 입/출고 이력', url: '/moldinout/report'}
];
export const partsList: ILinkInfo[] = [
    {category: '부품', label:'부품 마스터', url: '/parts/master'},
    {category: '부품', label:'부품 입고', url: '/parts/in'},
    {category: '부품', label:'부품 출고', url: '/parts/out'},
    {category: '부품', label:'부품 입/출고 현황', url: '/parts/inoutreport'},
    {category: '부품', label:'부품 재고 현황', url: '/parts/stock'},
    {category: '부품', label:'부품 사용 현황', url: '/parts/usereport'}
];

export const totalLinkList: ILinkInfo[] = concat(baseInfoList, moldCntList, moldRepairList, moldCheckList, moldInOutList, partsList);