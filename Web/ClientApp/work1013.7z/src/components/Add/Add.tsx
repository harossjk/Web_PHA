import { indexOf } from "lodash";
import React, { useState } from "react";
import { IButtonInfo } from "../ContentHeader/ContentHeader";
import myStyle from "./Add.module.scss";
import ContentHeader from "../ContentHeader";
import SubmitButton from "../SubmitButton";
import { toJS } from "mobx";
interface props {
  title: string;
  setBtnClick: any;
  userData: Array<any>;
  headerName: Array<any>;
  mappingObj?: any;
  mustInput?: any;
  modalMenu?: any;
  modalMenuContents?: any;
}

const Add = ({
  title,
  setBtnClick,
  userData,
  headerName,
  mappingObj,
  mustInput,
  modalMenu,
  modalMenuContents,
}: props) => {
  const headerNameMapping: any = [];
  const array: any[] = [];

  const controllData = headerName.map((element2: any, index: any) => {
    // 필수 입력 설정
    if (mustInput !== undefined && mustInput.includes(headerName[index])) {
      headerNameMapping.push(
        <span>
          {headerName[index]}
          <span className={myStyle.spanStyle}> (필수)</span>
        </span>
      );
    } else {
      headerNameMapping.push(headerName[index]);
    }

    // dropDown 설정
    if (mappingObj !== undefined) {
      mappingObj.map((element: any, idx: any) => {
        if (mappingObj[idx].title === headerName[index]) {
          array.push({ render: true, data: element });
        }
      });
      if (array[index] === undefined) {
        array.push({ render: false });
      }
    }

    // list 조건부 랜더링
    if (mappingObj !== undefined && array[index].render) {
      return (
        <li className={myStyle.listStyle} value={index}>
          {headerNameMapping[index]}
          <br />
          <input className={myStyle.inputStyle} list={index} />
          <datalist id={index}>
            {array[index].data.contents.map((element: any, idx: any) => {
              return <option value={element} />;
            })}
          </datalist>
        </li>
      );
    } else {
      return (
        <li className={myStyle.listStyle} value={index}>
          {headerNameMapping[index]}
          <br />
          <input className={myStyle.inputStyle} />
        </li>
      );
    }
  });

  //추가 버튼 클릭 이벤트
  const handleSummitClick: () => void = () => {
    console.log("추가 버튼 클릭!");
  };

  //취소 버튼 클릭 이벤트
  const handleCancelClick: () => void = () => {
    console.log("취소 버튼 클릭!");
    setBtnClick("");
  };

  const funcButtonInfos: IButtonInfo[] = [
    {
      label: "Add",
      key: "summit",
      backColor: "blue",
      onClick: handleSummitClick,
    },
    {
      label: "Cancel",
      key: "Cancel",
      backColor: "orange",
      onClick: handleCancelClick,
    },
  ];

  const close = () => {
    setBtnClick("");
  };

  // 모달메뉴상태
  const [modalMenuBtn, setModalMenuBtn] = useState(0);

  return (
    <>
      <div className={myStyle.modal}>
        <div className={myStyle.container}>
          <div className={myStyle.title}>{title}</div>
          <div className={myStyle.close}>
            <span onClick={close}>&times;</span>
          </div>

          <hr className={myStyle.line} />

          {modalMenu !== undefined ? (
            <div>
              {modalMenu.map((element: any, index: any) => {
                return (
                  <button onClick={() => setModalMenuBtn(index)}>
                    {element}
                  </button>
                ); // style수정할 부분
              })}
              <br />
              {modalMenuContents.map((element: any, index: any) => {
                if (index === modalMenuBtn) {
                  return <div>{element.content}</div>;
                }
              })}
            </div>
          ) : (
            <div className={myStyle.dataList}>{controllData}</div>
          )}

          <div className={myStyle.selectbtn}>
            <SubmitButton buttons={funcButtonInfos} />
          </div>
        </div>
      </div>
    </>
  );
};

export default Add;
