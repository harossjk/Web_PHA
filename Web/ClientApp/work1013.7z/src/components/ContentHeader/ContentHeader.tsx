import myStyle from "./ContentHeader.module.scss";

export interface IButtonInfo {
  label: string;
  key: string;
  backColor: "blue" | "orange" | "gray";
  type?: "wide" | "normal";
  onClick: () => void;
}

interface IContentHeader {
  title?: string;
  buttons?: IButtonInfo[];
}

const ContentHeader = ({ title, buttons }: IContentHeader) => {
  const { mainContentBox, titleLabel, buttonBox } = myStyle;
  return (
    <div className={mainContentBox}>
      <span className={titleLabel}>{title}</span>
      <div className={buttonBox}>
        {buttons
          ? buttons.map((d) => {
              //default blue
              let backColor = "#47A6ED";
              if (d.backColor === "orange") backColor = "#ED8D47";
              else if (d.backColor === "gray") backColor = "#B6B6B6";

              //default small
              let type = "100px";
              if (d.type === "wide") type = "210px";

              return (
                <button
                  key={`func_btn_${d.key}`}
                  style={{ backgroundColor: backColor, width: type }}
                  onClick={d.onClick}
                >
                  {d.label}
                </button>
              );
            })
          : undefined}
      </div>
    </div>
  );
};
export default ContentHeader;
