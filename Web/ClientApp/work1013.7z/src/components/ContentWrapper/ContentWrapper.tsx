import myStyle from './ContentWrapper.module.scss';
import React from 'react';

type Center = 'center';
type SpaceBetween = 'space-between';
type Left = 'flex-start';
type Right = 'flex-end'
type Top = 'flex-start';
type Bottom = 'flex-end';
type Row = 'row';
type Column = 'column';

interface ContentWrapperProps{
    width?: string;
    height?: string;
    className?: string;
    children?: React.ReactNode;
    verticalAlign?: Center|SpaceBetween|Top|Bottom;
    horizonalAlign?: Center|SpaceBetween|Left|Right;
    flexDirection?: Row|Column;
}

const ContentWrapper = ({width, height='850px', className, children, verticalAlign, horizonalAlign, flexDirection}: ContentWrapperProps) => {
    const {wrapper} = myStyle;
    const w = width !== undefined ? width : 'inherit';
    const h = height !== undefined ? height : 'auto';
    const vAlign = verticalAlign !== undefined ? verticalAlign : 'center';
    const hAlign = horizonalAlign !== undefined ? horizonalAlign : 'flex-start';
    const fDirection = flexDirection !== undefined ? flexDirection : 'column';
    const myClass = `${wrapper} ${className}`;
    return (
    <div className={myClass} 
        style={{
            width: w, 
            height: h, 
            justifyContent:hAlign, 
            alignContent:vAlign, 
            flexDirection: fDirection,
            }}>
        {children}
    </div>
    )
}
export default ContentWrapper;