import { useState } from 'react';
import MenuLink from '../MenuLink';
import myStyle from './Header.module.scss';
import {baseInfoList, moldCntList, moldRepairList, moldCheckList, moldInOutList, partsList} from '../../asset/ts/urls';

const Header = () => {
    const {headerBox, mainContent, menuLabelBox, contentMap, contentMapOpen, menuLinkTitle} = myStyle;

    const [isOpen, setOpen] = useState<boolean>(false);

    const handleMouseEnter = () => setOpen(true);
    const handleMouseLeave = () => setOpen(false);

    const categoryList = ['기준 정보', '금형 타수/세척', '금형 수리', '금형 예방 점검', '금형 입/출고', '부품'];
   
    return <header className={headerBox}>
        <div className={mainContent}>
            <img alt={'현풍 로고'} />
            <div className={menuLabelBox} onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
                { categoryList.map((d, idx) => <span key={`category_${idx}`}>{d}</span>) }
            </div>
        </div>
        <div 
            className={`${contentMap} ${isOpen ? contentMapOpen : ''}`} 
            onMouseEnter={handleMouseEnter} 
            onMouseLeave={handleMouseLeave}>
            <span className={menuLinkTitle}>관리 항목</span>
            <MenuLink category='baseinfo' list={baseInfoList}/>
            <MenuLink category='moldcnt' list={moldCntList}/>
            <MenuLink category='moldrepair' list={moldRepairList}/>
            <MenuLink category='moldcheck' list={moldCheckList}/>
            <MenuLink category='moldinout' list={moldInOutList}/>
            <MenuLink category='parts' list={partsList}/>
        </div>
    </header>;
}
export default Header;