import myStyle from './HistoryLabel.module.scss';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import KeyboardArrowRightIcon from '@material-ui/icons/KeyboardArrowRight';

interface IHistoryLabel{
    className?: string,
    category: string|undefined,
    page: string|undefined
}

const HistoryLabel = ({className='', category='', page=''}: IHistoryLabel) => {
    const {mainContentBox, categoryLabel, pageLabel, ArrowIconLabel} = myStyle;
    return <div className={`${mainContentBox} ${className}`}>
        <span className={categoryLabel}>{category}</span>
        <KeyboardArrowRightIcon className={ArrowIconLabel}/>
        <span className={pageLabel}>{`${page} 페이지`}</span>
    </div>
}
export default HistoryLabel;