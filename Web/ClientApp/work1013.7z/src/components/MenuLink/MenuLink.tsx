import { Link } from 'react-router-dom';
import { ILinkInfo } from '../../stores/appManager';
import myStyle from './MenuLink.module.scss';

interface IMenuLink{
    category: string,
    list: ILinkInfo[]
}

const MenuLink = ({category, list}:IMenuLink) => {
    const {menuLinkBox} = myStyle;
    return <div className={menuLinkBox}>
        { 
            list.map((d, idx) => 
                <Link key={`menu_link_${category}_${idx}`} to={d.url}> 
                    <span>{d.label}</span>
                </Link>) 
        }
    </div>
}
export default MenuLink;