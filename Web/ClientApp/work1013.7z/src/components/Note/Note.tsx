import React from "react";
import myStyle from "./Note.module.scss";

const Note = () => {
  const handleOnclick = () => {
    console.log("파일 찾기 클릭");
  };
  return (
    <div className={myStyle.layout}>
      <div className={myStyle.imageInput}>비고</div>
      <div className={myStyle.controllBox}>
        <input
          className={myStyle.inputBox}
          placeholder="선택 된 파일 없음"
          disabled
        >
          {/* <input>선택 된 파일 없음</input> */}
        </input>
        <div className={myStyle.searchBotton} onClick={handleOnclick}>
          파일찾기
        </div>
      </div>
    </div>
  );
};

export default Note;
