import myStyle from "./ContentTable.module.scss";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";

interface IContentTable {
  columnDefs: any;
  rowData?: any; //임시로 안들어와도 되게 설정
  setClickedData?: any;
}

const ContentTable = ({ columnDefs, rowData, setClickedData }: IContentTable) => {
  const { contentTable } = myStyle;

  const onSelectChanged = (e: any) => {
    setClickedData(e.api.getSelectedRows());
  };

  return (
    <div
      className={`${contentTable} ag-theme-alpine`}
      style={{ width: "100%", height: "50%" }}
    >
      <AgGridReact
        columnDefs={columnDefs}
        rowData={rowData ? rowData : []}
        defaultColDef={{ floatingFilter: true }}
        rowSelection="single"
        onSelectionChanged={onSelectChanged}
      />
    </div>
  );
};
export default ContentTable;
