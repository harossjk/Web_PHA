import _ from "lodash";
import { inject, observer } from "mobx-react";

import User from "../pages/BaseInfo/User";
import BaseCode from "../pages/BaseInfo/BaseCode";
import CarType from "../pages/BaseInfo/CarType";
import Recipe from "../pages/BaseInfo/Recipe";
import MoldMaster from "../pages/BaseInfo/MoldMaster";
import CheckSheet from "../pages/BaseInfo/CheckSheet";
import RFIDCode from "../pages/BaseInfo/RFIDCode";
import Partners from "../pages/BaseInfo/Partners";
import { useEffect } from "react";
import useStore from "../stores";

interface IBaseInfoContainer {
  match?: any;
}
const BaseInfoContainer = ({ match }: IBaseInfoContainer) => {
  const { _baseInfoStore, _appManagerStore } = useStore();
  const content = _.defaultTo(match.params.content, "user");

  useEffect(() => {
    _appManagerStore.setCurrentLinkInfo(match.url);
    _baseInfoStore.initStart();
  }, [content]);

  return (
    <>
      {content === "user" && (
        <User
          usersData={_baseInfoStore.getUsersData}
          companysData={_baseInfoStore.getCompanysData}
          departmentData={_baseInfoStore.getDepartmentData}
          regiuserData={_baseInfoStore.getRegiUserData}
        />
      )}
      {content === "basecode" && (
        <BaseCode baseCodeData={_baseInfoStore.getBaseCodeData} />
      )}
      {content === "cartype" && (
        <CarType
          carTypeData={_baseInfoStore.getcarTypeData}
          companysData={_baseInfoStore.getCompanysData}
        />
      )}
      {content === "recipe" && <Recipe />}
      {content === "moldmaster" && <MoldMaster />}
      {content === "checksheet" && <CheckSheet />}
      {content === "rfidcode" && <RFIDCode />}
      {content === "partners" && <Partners />}
    </>
  );
};
export default inject(({ stores }) => ({ appManager: stores.appManagerStore }))(
  observer(BaseInfoContainer)
);
