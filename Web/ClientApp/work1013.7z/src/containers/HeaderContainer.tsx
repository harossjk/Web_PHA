import Header from "../components/Header"

const HeaderContainer = () => {
    return <Header/>;
}
export default HeaderContainer;