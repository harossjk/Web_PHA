import _ from 'lodash';
import {inject, observer} from 'mobx-react'
import { useEffect } from 'react';
import Daily from '../pages/MoldCheck/Daily';
import NgRegistration from '../pages/MoldCheck/NgRegistration';
import Routine from '../pages/MoldCheck/Routine';
import RoutineReport from '../pages/MoldCheck/RoutineReport';
import useStore from '../stores'

interface IMoldCheckContainer{
    match?: any,
    
}

const MoldCheckContainer = ({match}: IMoldCheckContainer) => {
    const { _appManagerStore } = useStore();
    const content = _.defaultTo(match.params.content, 'routine');

    useEffect(() => {
        _appManagerStore.setCurrentLinkInfo(match.url)
    }, [content])
    
    return <>
        { content === 'routine' && <Routine /> }
        { content === 'routinereport' && <RoutineReport /> }
        { content === 'daily' && <Daily /> }
        { content === 'ngregistration' && <NgRegistration /> }
    </>;
}
export default inject(({stores}) => ({appManager: stores.appManagerStore}))(observer(MoldCheckContainer));