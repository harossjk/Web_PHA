import _ from "lodash";
import { inject, observer } from "mobx-react";
import { useEffect } from "react";
import MoldClean from "../pages/MoldCnt/MoldClean";
import MoldCnt from "../pages/MoldCnt/MoldCnt";
import MoldModify from "../pages/MoldCnt/MoldModify";
import useStore from "../stores";

interface IMoldCntContainer {
  match?: any;
}
const MoldCntContainer = ({ match }: IMoldCntContainer) => {
  const { _appManagerStore } = useStore();
  const content = _.defaultTo(match.params.content, "cnt");

  useEffect(() => {
    _appManagerStore.setCurrentLinkInfo(match.url);
  }, [content]);

  return (
    <>
      {content === "cnt" && <MoldCnt />}
      {content === "clean" && <MoldClean />}
      {content === "modify" && <MoldModify />}
    </>
  );
};
export default inject(({ stores }) => ({ appManager: stores.appManagerStore }))(
  observer(MoldCntContainer)
);
