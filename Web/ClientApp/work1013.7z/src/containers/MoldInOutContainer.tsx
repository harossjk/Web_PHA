import _ from 'lodash';
import {inject, observer} from 'mobx-react';
import { useEffect } from 'react';
import InOutReport from '../pages/MoldInOut/InOutReport';
import MoldIn from '../pages/MoldInOut/MoldIn';
import MoldOut from '../pages/MoldInOut/MoldOut';
import useStore from '../stores'
interface IMoldInOutContainer{
    match?: any,

}

const MoldInOutContainer = ({match}: IMoldInOutContainer) => {
    const { _appManagerStore } = useStore();
    const content = _.defaultTo(match.params.content, 'user');

    useEffect(() => {
        _appManagerStore.setCurrentLinkInfo(match.url)
    }, [content])

    return <>
        { content === 'in' && <MoldIn /> }
        { content === 'out' && <MoldOut /> }
        { content === 'report' && <InOutReport /> }
    </>;
}
export default inject(({stores})=>({appManager: stores.appManagerStore}))(observer(MoldInOutContainer));