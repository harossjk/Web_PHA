import _ from 'lodash';
import {inject, observer} from 'mobx-react';
import { useEffect } from 'react';
import CompleteResistration from '../pages/MoldRepair/CompleteResistration';
import RepairReport from '../pages/MoldRepair/RepairReport';
import RepairRequest from '../pages/MoldRepair/RepairRequest';

import useStore from '../stores'

interface IMoldRepairContainer{
    match?: any,

}

const MoldRepairContainer = ({match}: IMoldRepairContainer) => {
    const { _appManagerStore } = useStore();
    const content = _.defaultTo(match.params.content, 'request');

    useEffect(() => {
        _appManagerStore.setCurrentLinkInfo(match.url)
    }, [content])

    return <>
        { content === 'request' && <RepairRequest /> }
        { content === 'registration' && <CompleteResistration /> }
        { content === 'report' && <RepairReport /> }
    </>
}
export default inject(({stores})=>({appManager: stores.appManagerStore}))(observer(MoldRepairContainer))