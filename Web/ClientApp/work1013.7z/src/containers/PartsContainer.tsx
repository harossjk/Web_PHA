import _ from 'lodash';
import {inject, observer} from 'mobx-react';
import { useEffect } from 'react';
import InOutReport from '../pages/Parts/InOutReport';
import PartsIn from '../pages/Parts/PartsIn';
import PartsMaster from '../pages/Parts/PartsMaster';
import PartsOut from '../pages/Parts/PartsOut';
import PartsStock from '../pages/Parts/PartsStock';
import UseReport from '../pages/Parts/UseReport';
import useStore from '../stores'

interface IPartsContainer{
    match?: any,
}

const PartsContainer = ({match}: IPartsContainer) => {
    const { _appManagerStore } = useStore();
    const content = _.defaultTo(match.params.content, 'master');

    useEffect(() => {
        _appManagerStore.setCurrentLinkInfo(match.url)
    }, [content])

    return <>
        { content === 'master' && <PartsMaster /> }
        { content === 'in' && <PartsIn /> }
        { content === 'out' && <PartsOut /> }
        { content === 'inoutreport' && <InOutReport /> }
        { content === 'stock' && <PartsStock /> }
        { content === 'usereport' && <UseReport /> }
    </>
}
export default inject(({stores})=>({appManager: stores.appManagerStore}))(observer(PartsContainer))