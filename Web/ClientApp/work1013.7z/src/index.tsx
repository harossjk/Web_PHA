import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Layout from './pages/Layout';
import reportWebVitals from './reportWebVitals';
import {BrowserRouter} from 'react-router-dom';
import { Provider } from 'mobx-react';
import stores from './stores';

ReactDOM.render(
  <Provider stores={stores}>
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  </Provider>,
  document.getElementById('root')
);
reportWebVitals();
