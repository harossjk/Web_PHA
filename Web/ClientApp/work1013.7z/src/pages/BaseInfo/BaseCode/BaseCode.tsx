import myStyle from "./BaseCode.module.scss";
import Add from "../../../components/Add";
import ContentHeader from "../../../components/ContentHeader";
import { IButtonInfo } from "../../../components/ContentHeader/ContentHeader";
import ContentWrapper from "../../../components/ContentWrapper";
import Edit from "../../../components/Edit";
import ContentTable from "../../../components/Tables/ContentTable";
import { useState } from "react";

interface props {
  baseCodeData: any;
}

const BaseCode = ({ baseCodeData }: props) => {
  const [btnClick, setBtnClick] = useState("");
  const [clickedData, setClickedData] = useState([]);

  //수정 버튼 클릭 이벤트
  const handleEditClick: () => void = () => {
    console.log("수정 버튼 클릭!");
    if (clickedData.length !== 0) {
      setBtnClick("edit");
    } else {
      alert("데이터를 선택해주세요.");
    }
  };

  //추가 버튼 클릭 이벤트
  const handleAddClick: () => void = () => {
    setBtnClick("add");
    console.log("추가 버튼 클릭!");
  };

  //삭제 버튼 클릭 이벤트
  const handleDeleteClick: () => void = () => console.log("삭제 버튼 클릭!");

  const funcButtonInfos: IButtonInfo[] = [

    { label: "Edit", key: "edit", backColor: "blue", onClick: handleEditClick },
    { label: "Add", key: "add", backColor: "blue", onClick: handleAddClick },
    {
      label: "Delete",
      key: "delete",
      backColor: "orange",
      onClick: handleDeleteClick,
    },
  ];

  return (
    <div>
      <ContentWrapper>
        <ContentHeader title="사용자 관리" buttons={funcButtonInfos} />
        <ContentTable
          columnDefs={columnDef}
          rowData={baseCodeData}
          setClickedData={setClickedData}
        />
      </ContentWrapper>
      {btnClick === "edit" && (
        <Edit
          title="사용자 수정"
          userData={clickedData}
          setBtnClick={setBtnClick}
          headerName={headerName}
        />
      )}
      ,
      {btnClick === "add" && (
        <Add
          title="사용자 추가"
          userData={baseCodeData}
          setBtnClick={setBtnClick}
          headerName={headerName}
        />
      )}
    </div>
  );
};
export default BaseCode;

const headerName = [
  "회사",
  "사용자ID",
  "사용자명",
  "비밀번호",
  "부서",
  "발행자",
  "발행일",
];

const columnDef = [
  {
    checkboxSelection: true,
    width: 30,
  },
  {
    headerName: headerName[0],
    field: "company",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[1],
    field: "userid",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[2],
    field: "name",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[4],
    field: "department",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[5],
    field: "regiUser",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[6],
    field: "regidate",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
];
