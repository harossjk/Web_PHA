import { useState } from "react";
import ContentHeader from "../../../components/ContentHeader";
import { IButtonInfo } from "../../../components/ContentHeader/ContentHeader";
import ContentWrapper from "../../../components/ContentWrapper";
import ContentTable from "../../../components/Tables/ContentTable";
import myStyle from "./CheckSheet.module.scss";

const CheckSheet = () => {
  const [btnClick, setBtnClick] = useState("");
  const [clickedData, setClickedData] = useState([]);
  const { ContentTopMargin } = myStyle;

  //수정 버튼 클릭 이벤트
  const handleEditClick: () => void = () => {
    console.log("수정 버튼 클릭!");
    if (clickedData.length !== 0) {
      setBtnClick("edit");
    } else {
      alert("데이터를 선택해주세요.");
    }
  };

  //추가 버튼 클릭 이벤트
  const handleAddClick: () => void = () => {
    setBtnClick("add");
    console.log("추가 버튼 클릭!");
  };

  //삭제 버튼 클릭 이벤트
  const handleDeleteClick: () => void = () => console.log("삭제 버튼 클릭!");

  //엑셀 익스포트 버튼 클릭 이벤트
  const handleExportClick: () => void = () =>
    console.log("엑셀 출력 버튼 클릭!");

  //엑셀 익스포트 버튼 클릭 이벤트
  const handleDetailViewClick: () => void = () =>
    console.log("상세보기 버튼 클릭!");

  const funcButtonInfos: IButtonInfo[] = [
    { label: "Edit", key: "edit", backColor: "blue", onClick: handleEditClick },
    { label: "Add", key: "add", backColor: "blue", onClick: handleAddClick },
    {
      label: "Delete",
      key: "delete",
      backColor: "orange",
      onClick: handleDeleteClick,
    },
    {
      label: "Export",
      key: "export",
      backColor: "gray",
      onClick: handleExportClick,
    },
  ];

  const detailFuncButtonInfos: IButtonInfo[] = [
    {
      label: "상세보기",
      key: "detailView",
      backColor: "blue",
      type: "wide",
      onClick: handleDetailViewClick,
    },
  ];

  return (
    <div>
      <ContentWrapper>
        <ContentHeader title="점검 시트 리스트" buttons={funcButtonInfos} />
        <ContentTable columnDefs={columnDef} />
      </ContentWrapper>

      <ContentWrapper className={ContentTopMargin}>
        <ContentHeader
          title="선택 점검 시트 수정 내역"
          buttons={detailFuncButtonInfos}
        />
        <ContentTable columnDefs={detailColumnDef} />
      </ContentWrapper>
    </div>
  );
};
export default CheckSheet;

const columnDef = [
  {
    headerName: "금형 종류",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "점검 시트 종류",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "점검 시트명",
    field: "",
    minWidth: 200,
    flex: 2,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "점검 시트 시작일",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "점검 시트 종료일",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
];

const detailColumnDef = [
  {
    headerName: "버전",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "작성일",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "작성자",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
];
