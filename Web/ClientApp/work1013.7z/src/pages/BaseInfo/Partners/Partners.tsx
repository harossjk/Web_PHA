import { useState } from "react";
import ContentHeader from "../../../components/ContentHeader";
import { IButtonInfo } from "../../../components/ContentHeader/ContentHeader";
import ContentWrapper from "../../../components/ContentWrapper";
import ContentTable from "../../../components/Tables/ContentTable";
import myStyle from "./Partners.module.scss";

const Partners = () => {
  const [btnClick, setBtnClick] = useState("");
  const [clickedData, setClickedData] = useState([]);
  
  //수정 버튼 클릭 이벤트
  const handleEditClick: () => void = () => {
    console.log("수정 버튼 클릭!");
    if (clickedData.length !== 0) {
      setBtnClick("edit");
    } else {
      alert("데이터를 선택해주세요.");
    }
  };

  //추가 버튼 클릭 이벤트
  const handleAddClick: () => void = () => {
    setBtnClick("add");
    console.log("추가 버튼 클릭!");
  };

  //삭제 버튼 클릭 이벤트
  const handleDeleteClick: () => void = () => console.log("삭제 버튼 클릭!");

  //엑셀 익스포트 버튼 클릭 이벤트
  const handleExportClick: () => void = () =>
    console.log("엑셀 출력 버튼 클릭!");

  const funcButtonInfos: IButtonInfo[] = [
    { label: "Edit", key: "edit", backColor: "blue", onClick: handleEditClick },
    { label: "Add", key: "add", backColor: "blue", onClick: handleAddClick },
    {
      label: "Delete",
      key: "delete",
      backColor: "orange",
      onClick: handleDeleteClick,
    },
    {
      label: "Export",
      key: "export",
      backColor: "gray",
      onClick: handleExportClick,
    },
  ];

  return (
    <div>
      <ContentWrapper>
        <ContentHeader title="협력사 리스트" buttons={funcButtonInfos} />
        <ContentTable columnDefs={columnDef} />
      </ContentWrapper>
    </div>
  );
};
export default Partners;

const columnDef = [
  {
    headerName: "회사",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "협력사 코드",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "협력사 명",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "사업자번호",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "주소",
    field: "",
    minWidth: 600,
    flex: 3,
    filter: "agTextColumnFilter",
  },
];
