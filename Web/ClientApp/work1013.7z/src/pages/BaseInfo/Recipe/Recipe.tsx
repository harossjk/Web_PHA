import { useState } from "react";
import ContentHeader from "../../../components/ContentHeader";
import { IButtonInfo } from "../../../components/ContentHeader/ContentHeader";
import ContentWrapper from "../../../components/ContentWrapper";
import ContentTable from "../../../components/Tables/ContentTable";
import myStyle from "./Recipe.module.scss";

const Recipe = () => {
  const [btnClick, setBtnClick] = useState("");
  const [clickedData, setClickedData] = useState([]);
  
  //수정 버튼 클릭 이벤트
  const handleEditClick: () => void = () => {
    console.log("수정 버튼 클릭!");
    if (clickedData.length !== 0) {
      setBtnClick("edit");
    } else {
      alert("데이터를 선택해주세요.");
    }
  };

  //추가 버튼 클릭 이벤트
  const handleAddClick: () => void = () => {
    setBtnClick("add");
    console.log("추가 버튼 클릭!");
  };

  //삭제 버튼 클릭 이벤트
  const handleDeleteClick: () => void = () => console.log("삭제 버튼 클릭!");

  //엑셀 익스포트 버튼 클릭 이벤트
  const handleExportClick: () => void = () =>
    console.log("엑셀 출력 버튼 클릭!");

  const funcButtonInfos: IButtonInfo[] = [
    { label: "Edit", key: "edit", backColor: "blue", onClick: handleEditClick },
    { label: "Add", key: "add", backColor: "blue", onClick: handleAddClick },
    {
      label: "Delete",
      key: "delete",
      backColor: "orange",
      onClick: handleDeleteClick,
    },
    {
      label: "Export",
      key: "export",
      backColor: "gray",
      onClick: handleExportClick,
    },
  ];

  return (
    <div>
      <ContentWrapper>
        <ContentHeader title="품목 리스트" buttons={funcButtonInfos} />
        <ContentTable columnDefs={columnDef} />
      </ContentWrapper>
    </div>
  );
};
export default Recipe;

const columnDef = [
  {
    headerName: "작성자",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "품목코드",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "품명",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "차종코드",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "차종명",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "END-PNO",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: "SUB-PNO",
    field: "",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
];
