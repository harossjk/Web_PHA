import { toJS } from "mobx";
import { useState } from "react";
import Add from "../../../components/Add";
import ContentHeader from "../../../components/ContentHeader";
import { IButtonInfo } from "../../../components/ContentHeader/ContentHeader";
import ContentWrapper from "../../../components/ContentWrapper";
import Edit from "../../../components/Edit";
import ContentTable from "../../../components/Tables/ContentTable";
import myStyle from "./User.module.scss";

interface props {
  usersData: any;
  companysData: any;
  departmentData: any;
  regiuserData: any;
}

const UserManage = ({
  usersData,
  companysData,
  departmentData,
  regiuserData,
}: props) => {
  const [btnClick, setBtnClick] = useState("");
  const [clickedData, setClickedData] = useState([]);

  //사용자 권한 부여 버튼 클릭 이벤트
  const handleSetPermissionClick: () => void = () => {
    console.log("권한부여 버튼 클릭!");
  };

  //수정 버튼 클릭 이벤트
  const handleEditClick: () => void = () => {
    console.log("수정 버튼 클릭!");
    if (clickedData.length !== 0) {
      setBtnClick("edit");
    } else {
      alert("데이터를 선택해주세요.");
    }
  };

  //추가 버튼 클릭 이벤트
  const handleAddClick: () => void = () => {
    setBtnClick("add");
    console.log("추가 버튼 클릭!");
  };

  //삭제 버튼 클릭 이벤트
  const handleDeleteClick: () => void = () => console.log("삭제 버튼 클릭!");

  //헤드버튼
  const funcButtonInfos: IButtonInfo[] = [
    {
      label: "Set Permissions",
      key: "permission",
      backColor: "blue",
      type: "wide",
      onClick: handleSetPermissionClick,
    },
    { label: "Edit", key: "edit", backColor: "blue", onClick: handleEditClick },
    { label: "Add", key: "add", backColor: "blue", onClick: handleAddClick },
    {
      label: "Delete",
      key: "delete",
      backColor: "orange",
      onClick: handleDeleteClick,
    },
  ];

  //dropDown 매핑
  const mappingObj = [
    {
      // title : 회사
      title: headerName[0],
      contents: companysData.map((element: any) => {
        return element.company;
      }),
    },
    {
      // tile: 부서
      title: headerName[4],
      contents: departmentData.map((element: any) => {
        return element.department;
      }),
    },
    {
      // tile: 발행자
      title: headerName[5],
      contents: regiuserData.map((element: any) => {
        return element.regiuser;
      }),
    },
  ];

  return (
    <div>
      <ContentWrapper>
        <ContentHeader title="사용자 관리" buttons={funcButtonInfos} />
        <ContentTable
          columnDefs={columnDef}
          rowData={usersData}
          setClickedData={setClickedData}
        />
      </ContentWrapper>
      {btnClick === "edit" && (
        <Edit
          title="사용자 수정"
          userData={clickedData}
          setBtnClick={setBtnClick}
          headerName={headerName}
          mappingObj={mappingObj}
          mustInput={mustInput}
          modalMenu={modalMenu}
          modalMenuContents={modalMenuContents}
        />
      )}
      ,
      {btnClick === "add" && (
        <Add
          title="사용자 추가"
          userData={usersData}
          setBtnClick={setBtnClick}
          headerName={headerName}
          mappingObj={mappingObj}
          mustInput={mustInput}
          // modalMenu={modalMenu}
          // modalMenuContents={modalMenuContents}
        />
      )}
    </div>
  );
};
export default UserManage;
const modalMenu = [
  "금형 기본 정보",
  "금형 상세 정보",
  "기타 정보",
  "금형 품목",
  "추가 투자 금액",
];

const modalMenuContents = [
  { id: 0, content: "데이터0" },
  { id: 1, content: "데이터1" },
  { id: 2, content: "데이터2", image: "image" },
  { id: 3, content: "데이터3", note: "비고" },
  { id: 4, content: "데이터4", image: "이미지", note: "비고" },
];

const mustInput = ["회사", "사용자ID", "사용자명", "비밀번호"];

const headerName = [
  "회사",
  "사용자ID",
  "사용자명",
  "비밀번호",
  "부서",
  "발행자",
  "발행일",
];

const columnDef = [
  {
    checkboxSelection: true,
    width: 30,
  },
  {
    headerName: "회사",
    field: "company",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[1],
    field: "userid",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[2],
    field: "name",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[4],
    field: "department",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[5],
    field: "regiuser",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
  {
    headerName: headerName[6],
    field: "regidate",
    minWidth: 200,
    flex: 1,
    filter: "agTextColumnFilter",
  },
];
