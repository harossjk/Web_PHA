import myStyle from "./Layout.module.scss";
import { Route, Switch } from "react-router";
import BaseInfoContainer from "../../containers/BaseInfoContainer";
import HeaderContainer from "../../containers/HeaderContainer";
import HistoryLabel from "../../components/HistoryLabel";
import { inject, observer } from "mobx-react";

import MoldCntContainer from "../../containers/MoldCntContainer";
import MoldRepairContainer from "../../containers/MoldRepairContainer";
import MoldCheckContainer from "../../containers/MoldCheckContainer";
import MoldInOutContainer from "../../containers/MoldInOutContainer";
import PartsContainer from "../../containers/PartsContainer";
import useStore from "../../stores/";

const Layout = () => {
  const { _appManagerStore } = useStore();
  const { mainContent, pageBox, historyLabel } = myStyle;

  const linkInfo = _appManagerStore?.currentLinkInfo;

  return (
    <div className={mainContent}>
      <HeaderContainer />
      {/* mobx 적용 후 현재 페이지 observable 변수의 정보를 HistoryLabel에 매칭할것. */}
      <HistoryLabel
        className={historyLabel}
        category={linkInfo?.category}
        page={linkInfo?.label}
      />
      <div className={pageBox}>
        <Switch>
          <Route exact path="/" component={BaseInfoContainer} />
          <Route
            exact
            path="/baseinfo/:content"
            component={BaseInfoContainer}
          />
          <Route exact path="/moldcnt/:content" component={MoldCntContainer} />
          <Route
            exact
            path="/moldrepair/:content"
            component={MoldRepairContainer}
          />
          <Route
            exact
            path="/moldcheck/:content"
            component={MoldCheckContainer}
          />
          <Route
            exact
            path="/moldinout/:content"
            component={MoldInOutContainer}
          />
          <Route exact path="/parts/:content" component={PartsContainer} />
        </Switch>
      </div>
    </div>
  );
};
export default inject(({ stores }) => ({ appManager: stores.appManagerStore }))(
  observer(Layout)
);
