import ContentHeader from '../../../components/ContentHeader';
import ContentWrapper from '../../../components/ContentWrapper';
import ContentTable from '../../../components/Tables/ContentTable';
import myStyle from './NgRegistration.module.scss';

const NgRegistration = () => {
    const {contentMargin} = myStyle;

    //선택 항목 조치 완료 등록 클릭 이벤트
    const handleCompleteClick: () => void = () => console.log('선택 항목 조치 완료 버튼 클릭!');

    return <div>
        <ContentWrapper height='220px'>
            <ContentHeader title='조회 조건 설정'/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='NG 리스트'/>
            <ContentTable columnDefs={columnDef}/>
            <button onClick={handleCompleteClick}>
                선택 항목 조치 완료 등록
            </button>
        </ContentWrapper>
    </div>
}
export default NgRegistration;

const columnDef = [
    { 
        headerName: '금형 정보',
        children: [
            { headerName: '금형코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
            { headerName: '금형명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
            { headerName: '차종코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
        ]
    }
]