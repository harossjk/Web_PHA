import ContentHeader from '../../../components/ContentHeader';
import { IButtonInfo } from '../../../components/ContentHeader/ContentHeader';
import ContentWrapper from '../../../components/ContentWrapper';
import myStyle from './Routine.module.scss';

const Routine = () => {
    const {contentMargin} = myStyle;

    return <div>
        <ContentWrapper height='220px'>
            <ContentHeader title='조회 조건 설정'/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='점검일 캘린더'/>
        </ContentWrapper>
    </div>
}
export default Routine;