import ContentHeader from '../../../components/ContentHeader';
import { IButtonInfo } from '../../../components/ContentHeader/ContentHeader';
import ContentWrapper from '../../../components/ContentWrapper';
import ContentTable from '../../../components/Tables/ContentTable';
import myStyle from './RoutineReport.module.scss';

const RoutineReport = () => {
    const {contentMargin} = myStyle;

    //수정 버튼 클릭 이벤트
    const handleExportClick: () => void = () => console.log('엑셀 익스포트 버튼 클릭!');

    const funcButtonInfos: IButtonInfo[] = [
        {label: 'Export', key: 'export', backColor: 'gray', onClick: handleExportClick}
    ]

    return <div>
        <ContentWrapper height='220px'>
            <ContentHeader title='조회 조건 설정'/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='금형 리스트'/>
            <ContentTable columnDefs={columnDef}/>
        </ContentWrapper>
    </div>
}
export default RoutineReport;

const {rightBorder} = myStyle;

const columnDef = [
    { 
        headerName: '금형 정보',
        children: [
            { headerName: '금형코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
            { headerName: '금형명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
            { headerName: '차종코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
            { headerName: '점검 필요 횟수', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter", cellClass: `${rightBorder}`},
        ]
    },
    { 
        headerName: '1차 점검',
        children: [
            { headerName: '예정일', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
            { headerName: '점검일', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
            { headerName: '상태', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
        ]
    },
]

