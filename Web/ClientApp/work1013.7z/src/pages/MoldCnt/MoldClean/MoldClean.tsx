import ContentHeader from '../../../components/ContentHeader';
import { IButtonInfo } from '../../../components/ContentHeader/ContentHeader';
import ContentWrapper from '../../../components/ContentWrapper';
import ContentTable from '../../../components/Tables/ContentTable';
import myStyle from './MoldClean.module.scss';

const MoldClean = () => {
    const {contentMargin} = myStyle;

    //수정 버튼 클릭 이벤트
    const handleEditClick: () => void = () => console.log('수정 버튼 클릭!');

    //추가 버튼 클릭 이벤트
    const handleAddClick: () => void = () => console.log('추가 버튼 클릭!');

    //삭제 버튼 클릭 이벤트
    const handleDeleteClick: () => void = () => console.log('삭제 버튼 클릭!');

    const funcButtonInfos: IButtonInfo[] = [
        {label: 'Edit', key: 'edit', backColor: 'blue', onClick: handleEditClick},
        {label: 'Add', key: 'add', backColor: 'blue', onClick: handleAddClick},
        {label: 'Delete', key: 'delete', backColor: 'orange', onClick: handleDeleteClick},
    ]

    return <div>
        <ContentWrapper height='220px'>
            <ContentHeader title='조회 조건 설정'/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='금형 리스트'/>
            <ContentTable columnDefs={columnDef}/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='선택 금형 세척 리스트' buttons={funcButtonInfos}/>
            <ContentTable columnDefs={selectedMoldColumnDef}/>
        </ContentWrapper>
    </div>
}
export default MoldClean;

const columnDef = [
    { headerName: '금형코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '금형명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '품목코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '품목명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '생산기준일', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '차종명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
]

const selectedMoldColumnDef = [
    { headerName: '세척일', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '세척자', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '세척시 타수', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '수명 타수', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '세척 타수', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '총 누적 타수', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
]