import ContentHeader from '../../../components/ContentHeader';
import { IButtonInfo } from '../../../components/ContentHeader/ContentHeader';
import ContentWrapper from '../../../components/ContentWrapper';
import ContentTable from '../../../components/Tables/ContentTable';
import myStyle from './InOutReport.module.scss';

const InOutReport = () => {
    const {contentMargin} = myStyle;

    //엑셀 익스포트 버튼 클릭 이벤트
    const handleExportClick: () => void = () => console.log('엑셀 익스포트 버튼 클릭!');

    const funcButtonInfos: IButtonInfo[] = [
        {label: 'Export', key: 'export', backColor: 'gray', onClick: handleExportClick},
    ]

    return <div>
        <ContentWrapper height='220px'>
            <ContentHeader title='조회 조건 설정'/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='금형 입고 리스트' buttons={funcButtonInfos}/>
            <ContentTable columnDefs={columnDef}/>
        </ContentWrapper>
    </div>
}
export default InOutReport;

const columnDef = [
    { headerName: '금형코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '금형명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: 'PNO', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: 'SUB_PNO', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: 'SUB_PNAME', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '공정', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
]
