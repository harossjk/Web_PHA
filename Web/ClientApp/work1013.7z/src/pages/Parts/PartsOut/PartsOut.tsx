import ContentHeader from '../../../components/ContentHeader';
import { IButtonInfo } from '../../../components/ContentHeader/ContentHeader';
import ContentWrapper from '../../../components/ContentWrapper';
import ContentTable from '../../../components/Tables/ContentTable';
import myStyle from './PartsOut.module.scss';

const PartsOut = () => {
    const {contentMargin} = myStyle;

    //수정 버튼 클릭 이벤트
    const handleEditClick: () => void = () => console.log('수정 버튼 클릭!');

    //추가 버튼 클릭 이벤트
    const handleAddClick: () => void = () => console.log('추가 버튼 클릭!');

    //삭제 버튼 클릭 이벤트
    const handleDeleteClick: () => void = () => console.log('삭제 버튼 클릭!');

    const funcButtonInfos: IButtonInfo[] = [
        {label: 'Edit', key: 'edit', backColor: 'blue', onClick: handleEditClick},
        {label: 'Add', key: 'add', backColor: 'blue', onClick: handleAddClick},
        {label: 'Delete', key: 'delete', backColor: 'orange', onClick: handleDeleteClick},
    ]

    return <div>
        <ContentWrapper height='220px'>
            <ContentHeader title='조회 조건 설정'/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='금형 리스트'/>
            <ContentTable columnDefs={columnDef}/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='부품 리스트'/>
            <ContentTable columnDefs={partsColumnDef}/>
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
            <ContentHeader title='부품 출고 현황 리스트' buttons={funcButtonInfos}/>
            <ContentTable columnDefs={partsInColumnDef}/>
        </ContentWrapper>
    </div>
}
export default PartsOut;

const columnDef = [
    { headerName: '금형코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '금형명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '차종코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '차종명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '품목코트', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '품목명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
]

const partsColumnDef = [
    { headerName: '부품코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '부품명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '대분류', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '소분류', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '규격', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '재질', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
]

const partsInColumnDef = [
    { headerName: '출고 일자', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '출고 순번', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter" },
    { headerName: '부품 코드', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '부품명', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '규격', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
    { headerName: '재질', field: '', minWidth: 200, flex:1, filter:"agTextColumnFilter"},
]