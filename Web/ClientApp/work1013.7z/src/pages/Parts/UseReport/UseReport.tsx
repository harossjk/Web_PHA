import ContentHeader from "../../../components/ContentHeader";
import { IButtonInfo } from "../../../components/ContentHeader/ContentHeader";
import ContentWrapper from "../../../components/ContentWrapper";
import ContentTable from "../../../components/Tables/ContentTable";
import myStyle from './UseReport.module.scss';

const UseReport = () => {
    const { contentMargin } = myStyle;

    //엑셀 익스포트 버튼 클릭 이벤트
    const handleExportClick: () => void = () =>
      console.log("엑셀 출력 버튼 클릭!");
  
    const funcButtonInfos: IButtonInfo[] = [
      {
        label: "Export",
        key: "export",
        backColor: "gray",
        onClick: handleExportClick,
      },
    ];
  
    return (
      <div>
        <ContentWrapper height="220px">
          <ContentHeader title="조회 조건 설정" />
        </ContentWrapper>
        <ContentWrapper className={contentMargin}>
          <ContentHeader title="부품 사용 현황"  buttons={funcButtonInfos} />
          <ContentTable columnDefs={columnDef} />
        </ContentWrapper>
      </div>
    );
  };
  export default UseReport;
  
  const columnDef = [
    {
      headerName: "부품코드",
      field: "",
      minWidth: 200,
      flex: 1,
      filter: "agTextColumnFilter",
    },
    {
      headerName: "부품명",
      field: "",
      minWidth: 200,
      flex: 1,
      filter: "agTextColumnFilter",
    },
    {
      headerName: "부붐규격",
      field: "",
      minWidth: 200,
      flex: 1,
      filter: "agTextColumnFilter",
    },
    {
      headerName: "부품재질",
      field: "",
      minWidth: 200,
      flex: 1,
      filter: "agTextColumnFilter",
    },
    {
      headerName: "총 사용 수량",
      field: "",
      minWidth: 200,
      flex: 1,
      filter: "agTextColumnFilter",
    },
    {
      headerName: "총 출고 수량",
      field: "",
      minWidth: 200,
      flex: 1,
      filter: "agTextColumnFilter",
    },
  ];
  