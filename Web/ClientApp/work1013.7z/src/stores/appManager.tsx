import {makeObservable, observable, action, computed} from 'mobx';
import { totalLinkList } from '../asset/ts/urls';

export interface ILinkInfo{
    category: string,
    label: string, 
    url: string
}

class appManager {
    currentLinkInfo: ILinkInfo|undefined = {category:'', label:'', url: ''};

    constructor() {
        makeObservable(this,{
            currentLinkInfo: observable
        });
    }

    setCurrentLinkInfo = (url: string) => {
        this.currentLinkInfo = totalLinkList.find(x => x.url === url);
    }
}
export default appManager;