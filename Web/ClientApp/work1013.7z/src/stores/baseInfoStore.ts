import axios from "axios";
import { makeObservable, observable, action, computed, toJS } from "mobx";
import { configure } from "mobx";

const baseURL = `http://localhost:4000`;

export const urls = {
  user: `${baseURL}/users`,
  cartype: `${baseURL}/cartype`,
  companyList: `${baseURL}/companyList`,
  departmentList: `${baseURL}/departmentList`,
  regiUserData: `${baseURL}/regiUserData123`,
};

export default class baseInfoStore {
  usersData: any[] = [];

  companysData: any[] = [];

  carTypeData: any[] = [];

  departmentData: any[] = [];

  regiUserData: any[] = [];

  constructor() {
    makeObservable(this, {
      usersData: observable,
      companysData: observable,
      departmentData : observable,
      carTypeData: observable,
      regiUserData: observable,

      downUser: action,
      downCompanyList: action,
      downCarType: action,
      downDepartmentList: action,
      downRegiUserList: action,


      getUsersData: computed,
      getCompanysData: computed,
      getcarTypeData: computed,
      
      getBaseCodeData: computed,
      getDepartmentData: computed,
      getRegiUserData: computed
    });
  }

  initStart = async () => {
    await this.downUser();
    await this.downCarType();
    await this.downCompanyList();
    await this.downDepartmentList();
    await this.downRegiUserList();
  };

  downUser = async () => {
    try {
      const response = await axios.get(urls.user);
      console.log("axios에서 가져온  유저데이터", response.data);
      this.usersData = response.data;
    } catch (err) {
      console.log(err);
    }
  };

  downCarType = async () => {
    try {
      const response = await axios.get(urls.cartype);
      console.log("axios에서 가져온 카타입데이터", response.data);
      this.carTypeData = response.data;
    } catch (err) {
      console.log(err);
    }
  };

  downCompanyList = async () => {
    try {
      const response = await axios.get(urls.companyList);
      console.log("axios에서 가져온 회사리스트 데이터", response.data);
      this.companysData = response.data;
    } catch (err) {
      console.log(err);
    }
  };

  downDepartmentList = async () => {
    try {
      const response = await axios.get(urls.departmentList);
      console.log("axios에서 가져온 부서리스트 데이터", response.data);
      this.departmentData = response.data;
    } catch (err) {
      console.log(err);
    }
  };

  downRegiUserList = async () => {
    try {
      const response = await axios.get(urls.regiUserData);
      console.log("axios에서 가져온 발행자리스트 데이터", response.data);
      this.regiUserData = response.data;
    } catch (err) {
      console.log(err);
    }
  };

  get getUsersData() {
    return this.usersData;
    // return this.usersData.length > 0 ? this.usersData : InitialData;
  }

  get getCompanysData() {
    return this.companysData;
  }

  get getcarTypeData() {
    return this.carTypeData;
  }
  get getBaseCodeData() {
    return this.usersData; //임시로 usersdata
  }

  get getDepartmentData() {
    return this.departmentData; 
  }

  get getRegiUserData() {
    return this.regiUserData; 
  }
}
