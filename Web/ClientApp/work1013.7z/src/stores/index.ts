import appManager from "./appManager";
import baseInfoStore from "./baseInfoStore";

const _appManagerStore: appManager = new appManager();
const _baseInfoStore: baseInfoStore = new baseInfoStore();

const useStore = () => {
  return { _baseInfoStore, _appManagerStore };
};
export default useStore;
